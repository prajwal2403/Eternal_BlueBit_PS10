// filepath: d:\github\BlueBit hackathon\app\postcss.config.js
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}